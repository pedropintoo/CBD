Os datasets não foram colocados no elearning por motivos de tamanho máximo do arquivo .zip.
Podem ser encontrados em https://github.com/neelabalan/mongodb-sample-dataset/tree/main/sample_analytics
27-10-2024
