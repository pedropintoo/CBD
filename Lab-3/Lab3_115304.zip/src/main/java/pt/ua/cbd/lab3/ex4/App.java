package pt.ua.cbd.lab3.ex4;

public class App {
    
}
